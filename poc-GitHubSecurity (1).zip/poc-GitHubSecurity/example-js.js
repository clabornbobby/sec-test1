
var pg_port=1212;
var pg_host="gitguardians.com:9082/BLUDB";
var pg_user="root";
var pg_pass="sup3rstr0ngpass1ForGG";

var mongo_uri = "mongodb+srv://testuser:hub24aoeu@gg-is-awesome-gg273.mongodb.net/test?retryWrites=true&w=majority";